import { Request, Response, NextFunction } from 'express';
import { adminAuth } from '../lib/firebase-admin.ts';
import { DecodedIdToken } from 'firebase-admin/auth';

export interface AuthRequest extends Request {
  user?: DecodedIdToken & { isAdmin?: boolean };
}

const ADMIN_EMAILS = ['jaidykhan9@gmail.com'];

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing token' });
  }

  const token = authHeader.split('Bearer ')[1];
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    const isAdmin = Boolean(
      (decodedToken.email && ADMIN_EMAILS.includes(decodedToken.email.toLowerCase())) ||
      (decodedToken as any).admin
    );
    req.user = { ...decodedToken, isAdmin };
    next();
  } catch (error) {
    console.error('Error verifying Firebase ID token:', error);
    return res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
};

export const optionalAuth = async (
  req: AuthRequest,
  _res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split('Bearer ')[1];
    try {
      const decodedToken = await adminAuth.verifyIdToken(token);
      const isAdmin = Boolean(
        (decodedToken.email && ADMIN_EMAILS.includes(decodedToken.email.toLowerCase())) ||
        (decodedToken as any).admin
      );
      req.user = { ...decodedToken, isAdmin };
    } catch {
      // Ignore invalid optional tokens
    }
  }
  next();
};
